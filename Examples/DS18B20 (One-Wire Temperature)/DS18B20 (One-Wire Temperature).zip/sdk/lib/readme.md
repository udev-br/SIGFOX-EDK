# Don't forget to add the main static library here!
That is the libudev_sigfox_edk.a file, available at this repository, in the /Lib/ directory.