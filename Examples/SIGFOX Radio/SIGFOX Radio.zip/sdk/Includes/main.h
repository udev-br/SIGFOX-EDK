/*
 * main.h
 *
 * Created: 09-Nov-17 03:58:50 PM
 *  Author: Lucas Badur
 */ 


#ifndef MAIN_H_
#define MAIN_H_

void fnUSER_Setup ( void );
void fnUSER_Loop ( void );


#endif /* MAIN_H_ */