
#ifndef MAIN_H_
#define MAIN_H_


void fnUSER_Setup ( void );
void fnUSER_Loop ( void );

void fnWrite_Array_to_EEPROM( void );
void fnWrite_Integer_to_EEPROM( void );

#endif /* MAIN_H_ */