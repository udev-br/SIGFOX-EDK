
#ifndef MAIN_H_
#define MAIN_H_


void fnUSER_Setup ( void );
void fnUSER_Loop ( void );


#endif /* MAIN_H_ */