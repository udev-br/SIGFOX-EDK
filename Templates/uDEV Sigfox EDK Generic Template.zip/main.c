/*
 * This is a simple application example for the
 * LED present at the uDEV Sigfox EDK board.
 *
 */ 


#include "main.h"



void fnUSER_Setup( void )
{
   // This function will execute once, use it to initialize components and set initial values.
  
}

void fnUSER_Loop( void )
{
   // Anything within the USER_Loop context will execute continuously.
   // Check the header files for functions you can use in each program.
   
}

