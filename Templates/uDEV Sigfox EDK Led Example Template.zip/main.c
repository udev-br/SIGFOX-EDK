/*
 * This is a simple application example for the
 * LED present at the uDEV Sigfox EDK board.
 *
 */ 


#include "main.h"
#include "gpio.h"

bool switched = false;
bool pressed = false;

void fnUSER_Setup( void )
{
   // This function will execute once, use it to initialize components and set initial values.
   // In the case of the LED Example, this is not necessary, for the button and the LED are
   // always already initialized.
  
}

void fnUSER_Loop( void )
{
   // Anything within the USER_Loop context will execute continuously.
   // Check the header files for functions you can use in each program.
   
   if ( fnGPIO_BUTTON_Get_Level()==true )
   {
      pressed = true;
   }
   if ( fnGPIO_BUTTON_Get_Level()==false && pressed==true )
   {
      switched = !switched;
      fnGPIO_LED_Set_Level( switched );
      pressed = false;
   }
}

